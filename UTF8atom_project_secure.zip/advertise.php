<?php
require 'config.php';
validate_csrf();
if(!isLoggedIn()) header("Location: login.php");
$pdo = db();
$user = currentUser();

if($_SERVER['REQUEST_METHOD']=='POST'){
    $product_id = intval($_POST['product_id']);
    $ad_fee = 200.00;
    $reference = 'ATOM_AD_'.uniqid();
    $pdo->prepare("INSERT INTO transactions (user_id,reference,amount,type,status,meta) VALUES (?,?,?,?,?,?)")
        ->execute([$user['id'],$reference,$ad_fee,'advert_fee','pending',json_encode(['product_id'=>$product_id])]);

    $callback = BASE_URL . "/pay_verify.php?reference=".$reference;
    $data = ['email'=>$user['email'],'amount'=>intval($ad_fee*100),'reference'=>$reference,'callback_url'=>$callback,'metadata'=>['product_id'=>$product_id]];
    $ch = curl_init("https://api.paystack.co/transaction/initialize");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".PAYSTACK_SECRET,"Content-Type: application/json"]);
    $response = curl_exec($ch);
    $resp = json_decode($response, true);
    if($resp && $resp['status']){
        header("Location: ".$resp['data']['authorization_url']);
        exit;
    } else {
        $_SESSION['message'] = "Advert payment failed to initialize.";
        header("Location: marketplace.php");
        exit;
    }
}

$prods = $pdo->prepare("SELECT * FROM products WHERE user_id = ?");
$prods->execute([$user['id']]);
$prods = $prods->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Advertise</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h4>Advertise your product (₦200)</h4>
  <?php if(empty($prods)): ?>
    <div class="alert alert-warning">No products. <a href="add_product.php">Add product</a></div>
  <?php else: ?>
    <form method="post">
    <?php echo csrf_field(); ?>
      <div class="mb-3">
        <label>Select product</label>
        <select class="form-select" name="product_id">
          <?php foreach($prods as $p): ?>
            <option value="<?=$p['id']?>"><?=htmlspecialchars($p['title'])?> — ₦<?=number_format($p['price'],2)?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn btn-primary">Pay advert fee & advertise</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>