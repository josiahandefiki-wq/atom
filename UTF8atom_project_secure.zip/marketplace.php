<?php
require 'config.php';
if(!isLoggedIn()) header("Location: login.php");
$user = currentUser();
$pdo = db();

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_product'])){
    $product_id = intval($_POST['product_id']);
    $pstmt = $pdo->prepare("SELECT * FROM products WHERE id=? AND active=1");
    $pstmt->execute([$product_id]);
    $product = $pstmt->fetch(PDO::FETCH_ASSOC);
    if(!$product) { $_SESSION['message'] = "Product not found."; header("Location: marketplace.php"); exit; }

    $reference = 'ATOM_PUR_'.uniqid();
    $amount = $product['price'];
    $pdo->prepare("INSERT INTO transactions (user_id,reference,amount,type,status,meta) VALUES (?,?,?,?,?,?)")
        ->execute([$user['id'],$reference,$amount,'purchase','pending',json_encode(['product_id'=>$product_id,'seller_id'=>$product['user_id']])]);

    $callback = BASE_URL . "/pay_verify.php?reference=".$reference;
    $data = [
        'email' => $user['email'],
        'amount' => intval($amount * 100),
        'reference' => $reference,
        'callback_url' => $callback,
        'metadata' => ['buyer_id'=>$user['id'],'product_id'=>$product_id,'seller_id'=>$product['user_id']]
    ];
    $ch = curl_init("https://api.paystack.co/transaction/initialize");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer ".PAYSTACK_SECRET,
        "Content-Type: application/json"
    ]);
    $response = curl_exec($ch);
    $resp = json_decode($response, true);
    if($resp && $resp['status'] === true){
        header("Location: " . $resp['data']['authorization_url']);
        exit;
    } else {
        $_SESSION['message'] = "Payment initialization failed.";
    }
}

$msg = $_SESSION['message'] ?? null;
unset($_SESSION['message']);

$products = $pdo->query("SELECT p.*, u.username FROM products p LEFT JOIN users u ON p.user_id=u.id WHERE p.active=1 ORDER BY p.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Atom — Marketplace</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="#">🛒 Atom</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="marketplace.php">Marketplace</a></li>
        <li class="nav-item"><a class="nav-link" href="user_dashboard.php">👤 User Terminal</a></li>
        <li class="nav-item"><a class="nav-link" href="support.php">☎️ Support</a></li>
        <?php if($user['is_admin']): ?>
          <li class="nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
        <?php endif; ?>
      </ul>
      <div class="d-flex">
        <span class="navbar-text me-3">Hi, <?=htmlspecialchars($user['username'])?> (₦<?=number_format($user['earnings'],2)?>)</span>
        <a class="btn btn-outline-light" href="logout.php">Logout</a>
      </div>
    </div>
  </div>
</nav>

<header class="market-hero text-white text-center">
  <div class="overlay"></div>
  <div class="container hero-content">
    <h1 class="display-5">Atom Marketplace</h1>
    <p class="lead">Buy, sell and advertise — earn through affiliate sales.</p>
  </div>
</header>

<div class="container my-4">
  <?php if($msg): ?><div class="alert alert-info"><?=$msg?></div><?php endif; ?>

  <div class="row">
    <div class="col-md-8">
      <h4>Products</h4>
      <div class="row">
        <?php foreach($products as $p): ?>
          <div class="col-md-6">
            <div class="card mb-3">
              <div class="card-body">
                <h5><?=htmlspecialchars($p['title'])?></h5>
                <p class="text-muted">By <?=htmlspecialchars($p['username'])?></p>
                <p><?=htmlspecialchars(substr($p['description'],0,120))?></p>
                <?php if(!empty($p['image'])): ?>
                  <img src="assets/images/uploads/<?=htmlspecialchars($p['image'])?>" alt="" class="img-fluid mb-2" style="max-height:180px; object-fit:cover; width:100%;">
                <?php endif; ?>
                <p><strong>₦<?=number_format($p['price'],2)?></strong></p>
                <form method="post">
                  <input type="hidden" name="product_id" value="<?=$p['id']?>">
                  <button class="btn btn-success" name="buy_product">Buy</button>
                </form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="col-md-4">
      <h5>Sell / Advertise</h5>
      <?php if($user['subscription_status'] !== 'active'): ?>
        <div class="alert alert-warning">Activate subscription to advertise or sell. <a href="signup.php">Subscribe</a></div>
      <?php else: ?>
        <a class="btn btn-primary mb-3" href="add_product.php">Add Product</a>
        <a class="btn btn-outline-primary mb-3" href="advertise.php">Advertise Product (Pay Fee)</a>
      <?php endif; ?>

      <h5>Support</h5>
      <p>Contact support at <strong>support@atom.example</strong></p>
    </div>
  </div>
</div>
</body>
</html>