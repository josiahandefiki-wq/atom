<?php
require 'config.php';
validate_csrf();
$pdo = db();

$plans = [
  'gold' => ['label'=>'Gold','amount'=>3400.00],
  'premium' => ['label'=>'Premium','amount'=>9600.00]
];

$errors=[];
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $plan = $_POST['plan'] ?? 'free';

    if(!$username || !$email || !$password) $errors[] = "Please fill required fields.";

    $stmt = $pdo->prepare("SELECT id FROM users WHERE email=?");
    $stmt->execute([$email]);
    if($stmt->fetch()) $errors[] = "Email already registered.";

    if(empty($errors)){
        $pwd = password_hash($password, PASSWORD_DEFAULT);
        $sub_status = ($plan=='free') ? 'none' : 'pending';
        $pdo->prepare("INSERT INTO users (username,email,phone,password,subscription,subscription_status) VALUES (?,?,?,?,?,?)")
            ->execute([$username,$email,$phone,$pwd,$plan,$sub_status]);
        $user_id = $pdo->lastInsertId();

        if($plan!='free'){
            $amount = $plans[$plan]['amount'];
            $reference = 'ATOM_SUB_'.uniqid();
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id,reference,amount,type,status,meta) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$user_id,$reference,$amount,'subscription','pending',json_encode(['plan'=>$plan])]);

            $callback = BASE_URL . "/pay_verify.php?reference=".$reference;
            $data = [
                'email' => $email,
                'amount' => intval($amount * 100),
                'reference' => $reference,
                'callback_url' => $callback,
                'metadata' => ['user_id' => $user_id, 'plan' => $plan]
            ];

            $ch = curl_init("https://api.paystack.co/transaction/initialize");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: Bearer ".PAYSTACK_SECRET,
                "Content-Type: application/json"
            ]);
            $response = curl_exec($ch);
            if(!$response){
                die("Paystack init error: ".curl_error($ch));
            }
            $resp = json_decode($response, true);
            if($resp && $resp['status'] === true){
                header("Location: " . $resp['data']['authorization_url']);
                exit;
            }else{
                $errors[] = "Payment initialization failed.";
            }
        } else {
            $pdo->prepare("UPDATE users SET subscription_status='active', subscription_started=NOW() WHERE id=?")->execute([$user_id]);
            $_SESSION['user_id'] = $user_id;
            header("Location: marketplace.php");
            exit;
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Atom — Signup</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card p-4 shadow-sm">
        <h3>Create account</h3>
        <?php if($errors): ?>
          <div class="alert alert-danger"><?=implode('<br>',$errors)?></div>
        <?php endif; ?>
        <form method="post">
    <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input name="username" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input name="email" type="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Phone</label>
            <input name="phone" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input name="password" type="password" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Subscription plan</label>
            <select name="plan" class="form-select" required>
              <option value="free">Free (₦0) — limited</option>
              <option value="gold">Gold (₦3,400) — advertising & selling</option>
              <option value="premium">Premium (₦9,600) — premium features</option>
            </select>
          </div>

          <button class="btn btn-primary">Continue & Pay (if required)</button>
        </form>

        <p class="mt-3 text-muted">By continuing you agree to Atom terms.</p>
      </div>
    </div>
  </div>
</div>
</body>
</html>