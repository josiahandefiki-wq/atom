Atom - Affiliate Marketplace (ZIP)
=================================

What you received:
- Full PHP project files (place in your webserver)
- SQL schema: atom_db.sql
- Assets folder (css, js, images) - NOTE: you must add a background image

Important steps to make it work:
1. Put the 'atom_project' folder into your webserver document root (e.g., C:/xampp/htdocs/atom or /var/www/html/atom).
2. Import atom_db.sql into MySQL (phpMyAdmin or CLI):
   mysql -u root -p < atom_db.sql
3. Edit config.php:
   - Set DB_USER and DB_PASS if different
   - Set BASE_URL (e.g., http://localhost/atom)
   - Set PAYSTACK_SECRET and PAYSTACK_PUBLIC with your Paystack keys
4. Run setup.php once in your browser: http://localhost/atom/setup.php
   This creates the admin account:
     Email: admin@atom.local
     Password: atom@123
   After successful run DELETE setup.php for security.
5. Add a free stock background image:
   - Download a royalty-free image of two ultra-realistic people making a transaction (for example from Unsplash or Pexels).
   - Save it as: assets/images/transaction.jpg
   - That image will be used as the marketplace background.
6. Product image uploads:
   - Uploaded product images are saved to assets/images/uploads/
   - Ensure this folder is writable by the webserver (chmod 755 or 775 as needed).
   - Allowed formats: JPG, PNG, WEBP. Max size 5MB.
7. For Bootstrap, you can either:
   - Replace assets/css/bootstrap.min.css with the real bootstrap.min.css
   - Or edit header of PHP files to use CDN:
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
8. Configure Paystack:
   - Use test keys for development.
   - Set webhook URL in Paystack dashboard to https://yourdomain/atom/webhook.php (for local testing use ngrok).
9. Remove README and setup.php from production, secure config.php, and serve over HTTPS.

Notes:
- The project does NOT include the stock image due to packaging limits. Place your chosen image in assets/images/transaction.jpg.
- The navbar and terminals use icons you specified:
  - Marketplace: 🛒
  - User terminal: 👤
  - Support terminal: ☎️


SECURITY HARDENING ADDED:
- CSRF tokens on forms
- Session hardening and secure cookies
- Brute-force login protection (login_attempts table)
- Improved upload checks (finfo + getimagesize)
- Security HTTP headers (CSP, HSTS, X-Frame-Options, etc.)
- .htaccess protection for includes and uploads
- Optional Google reCAPTCHA support (set keys in config.php)
