<?php
// config.php - hardened
// Load early and send security headers
session_start();

// Session hardening: set cookie params and regenerate when needed
$cookieParams = session_get_cookie_params();
session_set_cookie_params([
    'lifetime' => $cookieParams['lifetime'],
    'path' => $cookieParams['path'],
    'domain' => $cookieParams['domain'],
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax'
]);

// If session is new, regenerate id to prevent fixation
if (empty($_SESSION['initiated'])) {
    session_regenerate_id(true);
    $_SESSION['initiated'] = true;
}

date_default_timezone_set('Africa/Lagos');

define('DB_HOST','127.0.0.1');
define('DB_NAME','atom_db');
define('DB_USER','root');
define('DB_PASS','');

define('PAYSTACK_SECRET','YOUR_PAYSTACK_SECRET_KEY');
define('PAYSTACK_PUBLIC','YOUR_PAYSTACK_PUBLIC_KEY');

define('BASE_URL','http://localhost/atom');

define('PLATFORM_FEE_PERCENT', 10.0);

// reCAPTCHA (optional) - obtain keys if you want to enable it
define('RECAPTCHA_SITE_KEY','');
define('RECAPTCHA_SECRET_KEY','');

// Brute-force settings
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_MINUTES', 15);

function db(){
    static $pdo = null;
    if($pdo === null){
        $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
    }
    return $pdo;
}

function isLoggedIn(){
    return !empty($_SESSION['user_id']);
}

function currentUser(){
    if(!isLoggedIn()) return null;
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/* ---------------- Security: CSRF ---------------- */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    $t = csrf_token();
    return '<input type="hidden" name="csrf_token" value="'.htmlspecialchars($t).'">';
}

function validate_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (empty($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            http_response_code(400);
            die('Invalid CSRF token');
        }
    }
}

/* ---------------- Security headers ---------------- */
function send_security_headers() {
    header("X-Frame-Options: SAMEORIGIN");
    header("X-Content-Type-Options: nosniff");
    header("Referrer-Policy: no-referrer-when-downgrade");
    header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
    header("Permissions-Policy: geolocation=(), microphone=()");
    header("Content-Security-Policy: default-src 'self' 'unsafe-inline' https:; img-src 'self' data: https:; frame-ancestors 'self';");
}
send_security_headers();

/* ---------------- reCAPTCHA verify (optional) ---------------- */
function verify_recaptcha($token) {
    if (empty(RECAPTCHA_SECRET_KEY)) return true; // treat as disabled
    $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'secret' => RECAPTCHA_SECRET_KEY,
        'response' => $token
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    if(!$res) return false;
    $data = json_decode($res, true);
    return !empty($data['success']) && $data['score'] >= 0.5 || !empty($data['success']);
}

/* ---------------- Login attempt helpers ---------------- */
function record_login_attempt($email) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO login_attempts (email, ip) VALUES (?, ?)");
    $stmt->execute([$email, $ip]);
}

function failed_attempts_count($email) {
    $pdo = db();
    $since = date('Y-m-d H:i:s', time() - (LOCKOUT_MINUTES * 60));
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM login_attempts WHERE email = ? AND attempt_time >= ?");
    $stmt->execute([$email, $since]);
    return (int)$stmt->fetchColumn();
}

function is_locked_out($email) {
    return failed_attempts_count($email) >= MAX_LOGIN_ATTEMPTS;
}

/* ---------------- Utility: safe output ---------------- */
function e($v) {
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}
?>