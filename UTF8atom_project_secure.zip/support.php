<?php
require 'config.php';
validate_csrf();
if(!isLoggedIn()) header('Location: login.php');
$user = currentUser();
$msg = '';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO settings (k,v) VALUES (?,?)");
    $stmt->execute(['support_'.time(), json_encode(['user'=>$user['id'],'subject'=>$subject,'message'=>$message])]);
    $msg = 'Support message sent. Our team will contact you.';
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Support</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h3>☎️ Support</h3>
  <?php if($msg): ?><div class="alert alert-success"><?=$msg?></div><?php endif; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3"><label>Subject</label><input name="subject" class="form-control" required></div>
    <div class="mb-3"><label>Message</label><textarea name="message" class="form-control" rows="6" required></textarea></div>
    <button class="btn btn-primary">Send</button>
  </form>
  <a href="marketplace.php" class="btn btn-secondary mt-3">Back</a>
</div>
</body>
</html>