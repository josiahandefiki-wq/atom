<?php
require 'config.php';
validate_csrf();
$pdo = db();
$err = '';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $recaptcha_token = $_POST['g-recaptcha-response'] ?? '';
    if(!verify_recaptcha($recaptcha_token)){
        $err = 'reCAPTCHA verification failed.';
    } else {
        if(is_locked_out($email)){
            $err = 'Too many failed attempts. Try again later.';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $u = $stmt->fetch(PDO::FETCH_ASSOC);
            if($u && password_verify($password, $u['password'])){
                // successful login: regenerate session id and clear old attempts
                session_regenerate_id(true);
                $_SESSION['user_id'] = $u['id'];
                // remove old attempts for this user
                $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE email = ?");
                $stmt->execute([$email]);
                header("Location: marketplace.php");
                exit;
            } else {
                record_login_attempt($email);
                $err = "Invalid credentials.";
            }
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Atom — Login</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card p-4 shadow">
        <h3>Login</h3>
        <?php if($err): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
        <form method="post">
    <?php echo csrf_field(); ?>
          <div class="mb-3"><label>Email</label><input name="email" type="email" class="form-control" required></div>
          <div class="mb-3"><label>Password</label><input name="password" type="password" class="form-control" required></div>
          <button class="btn btn-primary">Login</button>
        </form>
        <p class="mt-3">No account? <a href="signup.php">Sign up</a></p>
      </div>
    </div>
  </div>
</div>
</body>
</html>