<?php
require 'config.php';
validate_csrf();
if(!isLoggedIn()) header("Location: login.php");
$user = currentUser();
if(!$user['is_admin']) die("Access denied.");
$pdo = db();

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['action'])){
    $id = intval($_POST['id']);
    $action = $_POST['action'];
    if($action == 'approve'){
        $wstmt = $pdo->prepare("SELECT * FROM withdrawals WHERE id=?");
        $wstmt->execute([$id]);
        $w = $wstmt->fetch(PDO::FETCH_ASSOC);
        if($w){
            $count = $pdo->prepare("SELECT COUNT(*) FROM withdrawals WHERE user_id = ?");
            $count->execute([$w['user_id']]);
            $num = $count->fetchColumn();
            if($num == 1 && $w['amount'] > 1500){
                $pdo->prepare("UPDATE withdrawals SET status='rejected', admin_notes=? WHERE id=?")->execute(["First withdrawal exceed limit", $id]);
            } else {
                $pdo->prepare("UPDATE withdrawals SET status='paid', admin_notes=? WHERE id=?")->execute([$_POST['notes'] ?? 'Paid', $id]);
                $pdo->prepare("UPDATE users SET earnings = earnings - ? WHERE id=?")->execute([$w['amount'], $w['user_id']]);
            }
        }
    } elseif($action=='reject'){
        $pdo->prepare("UPDATE withdrawals SET status='rejected', admin_notes=? WHERE id=?")->execute([$_POST['notes'] ?? 'Rejected', $id]);
    }
}

$rows = $pdo->query("SELECT w.*, u.username, u.email FROM withdrawals w JOIN users u ON w.user_id=u.id ORDER BY w.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Admin Panel</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h3>Admin Panel</h3>
  <table class="table">
    <thead><tr><th>User</th><th>Amount</th><th>Status</th><th>Notes</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?=htmlspecialchars($r['username'])?> <br><small><?=htmlspecialchars($r['email'])?></small></td>
          <td>₦<?=number_format($r['amount'],2)?></td>
          <td><?=$r['status']?></td>
          <td><?=htmlspecialchars($r['admin_notes'])?></td>
          <td>
            <?php if($r['status']=='requested'): ?>
              <form method="post" style="display:inline">
                <input type="hidden" name="id" value="<?=$r['id']?>">
                <input type="hidden" name="action" value="approve">
                <input class="form-control mb-1" placeholder="notes" name="notes">
                <button class="btn btn-success btn-sm">Approve & Pay</button>
              </form>
              <form method="post" style="display:inline">
                <input type="hidden" name="id" value="<?=$r['id']?>">
                <input type="hidden" name="action" value="reject">
                <input class="form-control mb-1" placeholder="notes" name="notes">
                <button class="btn btn-danger btn-sm">Reject</button>
              </form>
            <?php else: echo "-"; endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a href="marketplace.php" class="btn btn-secondary">Back</a>
</div>
</body>
</html>