<?php
require 'config.php';
$payload = @file_get_contents('php://input');
$data = json_decode($payload, true);
if(!$data){
    http_response_code(400); echo "bad payload"; exit;
}
if(isset($data['event']) && $data['event'] == 'charge.success'){
    $ref = $data['data']['reference'] ?? null;
    $amount = ($data['data']['amount'] ?? 0) / 100;
    $metadata = $data['data']['metadata'] ?? [];

    $pdo = db();
    if($ref){
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE reference = ?");
        $stmt->execute([$ref]);
        $tx = $stmt->fetch(PDO::FETCH_ASSOC);
        if($tx && $tx['status'] != 'success'){
            $pdo->prepare("UPDATE transactions SET status='success' WHERE id=?")->execute([$tx['id']]);

            if($tx['type'] == 'subscription'){
                $meta = json_decode($tx['meta'], true);
                $plan = $meta['plan'] ?? 'gold';
                $pdo->prepare("UPDATE users SET subscription_status='active', subscription=?, subscription_started=NOW() WHERE id=?")
                    ->execute([$plan, $tx['user_id']]);
            }

            if($tx['type'] == 'purchase'){
                $meta = json_decode($tx['meta'], true);
                $product_id = $meta['product_id'] ?? null;
                $seller_id = $meta['seller_id'] ?? null;
                $price = floatval($tx['amount']);
                $platform_fee = round($price * (PLATFORM_FEE_PERCENT/100), 2);
                $seller_earning = round($price - $platform_fee, 2);

                $pdo->prepare("INSERT INTO orders (buyer_id,product_id,seller_id,price,platform_fee,seller_earning,tx_reference,status) VALUES (?,?,?,?,?,?,?,?)")
                    ->execute([$tx['user_id'],$product_id,$seller_id,$price,$platform_fee,$seller_earning,$tx['reference'],'completed']);

                $pdo->prepare("UPDATE users SET earnings = earnings + ? WHERE id = ?")->execute([$seller_earning, $seller_id]);
            }

            if($tx['type'] == 'advert_fee'){
                $meta = json_decode($tx['meta'], true);
                $product_id = $meta['product_id'] ?? null;
                if($product_id){
                    $pdo->prepare("UPDATE products SET is_advertised = 1 WHERE id = ?")->execute([$product_id]);
                }
            }
        }
    }
}

http_response_code(200);
echo 'ok';
?>