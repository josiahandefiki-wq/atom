<?php require 'config.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Atom — Introduction</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
  <div class="card shadow-sm mx-auto" style="max-width:900px">
    <div class="card-body">
      <h1 class="card-title">Welcome to Atom</h1>
      <p class="lead">Atom is an affiliate marketplace where users can buy products, sell their own items, advertise products and earn commission.</p>
      <ul>
        <li>Buy goods from other users</li>
        <li>Advertise and sell your products (10% platform fee)</li>
        <li>Track earnings & request withdrawals (admin must approve first withdrawal up to ₦1,500)</li>
      </ul>
      <div class="mt-4">
        <a href="signup.php" class="btn btn-primary">Sign up</a>
        <a href="login.php" class="btn btn-outline-secondary">Login</a>
      </div>
    </div>
  </div>
</div>
</body>
</html>