<?php
require 'config.php';
$pdo = db();

$reference = $_GET['reference'] ?? null;
if(!$reference) die("No reference provided");

$stmt = $pdo->prepare("SELECT * FROM transactions WHERE reference = ?");
$stmt->execute([$reference]);
$tx = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$tx) die("Transaction record not found");

if($tx['status'] == 'success'){
    header("Location: marketplace.php");
    exit;
}

$ch = curl_init("https://api.paystack.co/transaction/verify/" . urlencode($reference));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer ".PAYSTACK_SECRET
]);
$response = curl_exec($ch);
if(!$response) die("Verification failed: ".curl_error($ch));

$resp = json_decode($response, true);
if($resp && !empty($resp['data']) && $resp['data']['status'] == 'success'){
    $pdo->prepare("UPDATE transactions SET status='success' WHERE id=?")->execute([$tx['id']]);

    if($tx['type'] == 'subscription'){
        $meta = json_decode($tx['meta'], true);
        $plan = $meta['plan'] ?? 'gold';
        $pdo->prepare("UPDATE users SET subscription_status='active', subscription=?, subscription_started=NOW() WHERE id=?")
            ->execute([$plan, $tx['user_id']]);
    }

    $_SESSION['message'] = "Payment successful.";
    header("Location: marketplace.php");
    exit;
} else {
    $pdo->prepare("UPDATE transactions SET status='failed' WHERE id=?")->execute([$tx['id']]);
    die("Payment not successful.");
}
?>