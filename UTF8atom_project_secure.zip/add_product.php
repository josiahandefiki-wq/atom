<?php
require 'config.php';
validate_csrf();
if(!isLoggedIn()) header("Location: login.php");
$user = currentUser();
$pdo = db();

$err='';
$success='';

if($_SERVER['REQUEST_METHOD']=='POST'){
    $title = $_POST['title'] ?? '';
    $desc = $_POST['description'] ?? '';
    $price = floatval($_POST['price'] ?? 0);

    if(!$title || $price <= 0) $err = "Please provide title and valid price.";

    // Handle image upload if provided
    $image_filename = null;
    if(isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE){
        $allowed = ['image/jpeg','image/png','image/webp'];
        if($_FILES['image']['error'] !== UPLOAD_ERR_OK){
            $err = "Image upload error.";
        } else {
            // additional server-side checks
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $_FILES['image']['tmp_name']);
            finfo_close($finfo);
            $imginfo = @getimagesize($_FILES['image']['tmp_name']);
            if(!in_array($mime, $allowed) || !$imginfo){
                $err = "Only JPG, PNG and WEBP images are allowed.";
            } elseif($_FILES['image']['size'] > 5 * 1024 * 1024){
                $err = "Image too large. Max 5MB.";
            } else {
            $err = "Only JPG, PNG and WEBP images are allowed.";
        } elseif($_FILES['image']['size'] > 5 * 1024 * 1024){
            $err = "Image too large. Max 5MB.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_filename = 'prod_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
            $dest = __DIR__ . '/assets/images/uploads/' . $image_filename;
            if(!move_uploaded_file($_FILES['image']['tmp_name'], $dest)){
                $err = "Failed to save uploaded image.";
            }
        }
    }

    if(!$err){
        $stmt = $pdo->prepare("INSERT INTO products (user_id,title,description,price,image) VALUES (?,?,?,?,?)");
        $stmt->execute([$user['id'],$title,$desc,$price,$image_filename]);
        $success = "Product added successfully.";
        header("Location: marketplace.php");
        exit;
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add product</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h3>Add product</h3>
  <?php if($err): ?><div class="alert alert-danger"><?=$err?></div><?php endif; ?>
  <?php if($success): ?><div class="alert alert-success"><?=$success?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3"><label>Title</label><input name="title" class="form-control" required></div>
    <div class="mb-3"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
    <div class="mb-3"><label>Price (₦)</label><input name="price" type="number" step="0.01" class="form-control" required></div>
    <div class="mb-3"><label>Product image (optional, JPG/PNG/WEBP, max 5MB)</label><input name="image" type="file" accept="image/*" class="form-control"></div>
    <button class="btn btn-primary">Add product</button>
  </form>
</div>
</body>
</html>
