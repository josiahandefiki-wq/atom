// main.js - placeholder
console.log('Atom marketplace loaded');
