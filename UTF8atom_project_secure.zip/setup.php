<?php
// setup.php - run once and delete afterwards
require 'config.php';
$pdo = db();

$username = 'atom world';
$email = 'admin@atom.local';
$password = password_hash('atom@123', PASSWORD_DEFAULT);

$stmt = $pdo->prepare("SELECT id FROM users WHERE email=?");
$stmt->execute([$email]);
if($stmt->fetch()){
    echo "Admin user already exists. Delete setup.php for security.";
    exit;
}

$insert = $pdo->prepare("INSERT INTO users (username,email,password,is_admin,subscription_status) VALUES (?,?,?,?,?)");
$insert->execute([$username,$email,$password,1,'active']);
echo "Admin created: email=admin@atom.local password=atom@123. Delete setup.php for security.";
?>