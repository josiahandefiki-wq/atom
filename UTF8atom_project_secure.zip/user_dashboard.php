<?php
require 'config.php';
validate_csrf();
if(!isLoggedIn()) header("Location: login.php");
$user = currentUser();
$pdo = db();
$msg='';

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['request_withdrawal'])){
    $amount = floatval($_POST['amount'] ?? 0);
    if($amount <= 0) $msg = "Invalid amount.";
    elseif($amount > $user['earnings']) $msg = "Insufficient balance.";
    else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM withdrawals WHERE user_id = ?");
        $stmt->execute([$user['id']]);
        $count = $stmt->fetchColumn();
        if($count == 0 && $amount > 1500){
            $msg = "First withdrawal cannot exceed ₦1,500. Contact admin.";
        } else {
            $pdo->prepare("INSERT INTO withdrawals (user_id,amount,status) VALUES (?,?,?)")->execute([$user['id'],$amount,'requested']);
            $msg = "Withdrawal requested. Admin approval required.";
        }
    }
}

$with = $pdo->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC");
$with->execute([$user['id']]);
$withdrawals = $with->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>User Terminal</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h3>👤 User Terminal</h3>
  <p><strong><?=htmlspecialchars($user['username'])?></strong> — <?=htmlspecialchars($user['email'])?></p>
  <p>Earnings: <strong>₦<?=number_format($user['earnings'],2)?></strong></p>

  <?php if($msg): ?><div class="alert alert-info"><?=$msg?></div><?php endif; ?>

  <h5>Request Withdrawal</h5>
  <form method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3"><label>Amount (₦)</label><input name="amount" type="number" step="0.01" class="form-control" required></div>
    <button class="btn btn-primary" name="request_withdrawal">Request</button>
  </form>

  <h5 class="mt-4">Withdrawal History</h5>
  <table class="table">
    <thead><tr><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
    <tbody>
      <?php foreach($withdrawals as $w): ?>
        <tr><td>₦<?=number_format($w['amount'],2)?></td><td><?=$w['status']?></td><td><?=$w['created_at']?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <a href="marketplace.php" class="btn btn-secondary">Back to marketplace</a>
</div>
</body>
</html>